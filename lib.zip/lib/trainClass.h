// TRAINCLASS.h - Contains declaration of Function class  
#pragma once  

#ifdef TRAINCLASS_EXPORTS  
#define TRAINCLASS_API __declspec(dllexport)   
#else  
#define TRAINCLASS_API __declspec(dllimport)   
#endif  
#include <vector>
#include<opencv2\opencv.hpp>
#include<opencv2\core\core.hpp>
using namespace std;
using namespace cv;


namespace TRAINCLASS
{
	// This class is exported from the MathLibrary.dll  
	class trainConfig
	{
	public:
		string _centerImgDir;
		double _hightAngle;
		double _lowAngle;
		vector <Point> _pointLogo;
		string _projectDir;
		vector <Point> _iouLogo;
		string _configDir;
		int _creatImgNum;
		TRAINCLASS_API trainConfig(string projectDir , string centerImgDir, double hightAngle, double lowAngle, vector <Point> pointLogo);
		TRAINCLASS_API void calculateCreatImgNum();
	private:
		int creatImgNum;
	};
}
