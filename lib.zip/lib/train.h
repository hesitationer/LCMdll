// TRAIN.h - Contains declaration of Function class  
#pragma once  

// MathLibrary.h - Contains declaration of Function class  
#pragma once  

#ifdef TRAIN_EXPORTS  
#define TRAIN_API __declspec(dllexport)   
#else  
#define TRAIN_API __declspec(dllimport)   
#endif 
#include <vector>
#include <string>
#include<opencv2\opencv.hpp>
#include<opencv2\core\core.hpp>
#include "trainClass.h"
using namespace cv;
using namespace std;
using namespace  TRAINCLASS;
namespace TRAINLIB
{
	//TRAIN_API vector<CSVData> read_csv(const char* csv_file);
	TRAIN_API  void writeTrainConfigToCsv(trainConfig _trainConfig);
	//TRAIN_API  void readTrainConfig(const char* csv_file);
	TRAIN_API void mkdir(string dir);
	TRAIN_API Point get_romate_point(Point point, Point center, double angle);
	TRAIN_API void get_many_romate_point(Point Pts[4], Point new_pts[4], Point centerRotation, double angle);
	TRAIN_API void creat_img(trainConfig  trainConfig1);
}

